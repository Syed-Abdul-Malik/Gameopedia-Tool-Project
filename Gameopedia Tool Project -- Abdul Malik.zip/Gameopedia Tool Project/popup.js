// Function to get selected search options
function getSelectedOptions() {
  const selectedOptions = [];
  const checkboxes = document.querySelectorAll('.search-options input[type="checkbox"]:checked');
  [...checkboxes].forEach((checkbox) => {
    selectedOptions.push(checkbox.id);
  });
  return selectedOptions;
}

// Function to create search URLs
function createSearchURLs(selectedOptions, searchInput) {
  const searchURLs = {
    'mobygames': `https://www.mobygames.com/search/quick?q=${searchInput}`,
    'youtube': `https://www.youtube.com/results?search_query=${searchInput}`,
    'gamefaqs': `https://www.gamefaqs.com/search?game=${searchInput}`,
    'google': `https://www.google.com/search?q=${searchInput}`,
    'ns-us': `https://www.nintendo.com/us/search/#q=${searchInput}&t=software&f=game&nt=overview`,
    'ns-uk': `https://www.nintendo.co.uk/Search/Search-299117.html?q=${searchInput}&t=software&f=game&nt=overview`,
    'ns-japan': `https://www.nintendo.co.jp/search/index.html?q=${searchInput}&categories=software&n=1`,
    'xb-us': `https://www.xbox.com/en-US/search?q=${searchInput}`,
    'xb-uk': `https://www.xbox.com/en-gb/search?q=${searchInput}`,
    'xb-japan': `https://www.xbox.com/ja-jp/search?q=${searchInput}`,
    'steam': `https://store.steampowered.com/search/?term=${searchInput}`,
    'playstation': `https://store.playstation.com/search/${searchInput}`,
    'howlongtobeat': `https://howlongtobeat.com/search/?q=${searchInput}`,
    'vndb': `https://www.vndb.org/v/list?search=${searchInput}`,
    'pcgamingwiki': `https://www.pcgamingwiki.com/wiki/index.php?search=${searchInput}`,
    'imdb': `https://www.imdb.com/find?q=${searchInput}`,
  };

  // Only create URLs if there are selected options
  if (selectedOptions.length) {
    return selectedOptions.map((option) => searchURLs[option]);
  } else {
    return [];
  }
}

// Function to handle overall search with error handling
async function performSearch() {
  const searchInput = document.getElementById('search-input').value.trim();
  if (!searchInput) {
    alert('Please enter a search term');
    return;
  }

  const selectedOptions = getSelectedOptions();

  // Check if any options are selected before creating URLs
  if (!selectedOptions.length) {
    alert('Please select at least one search option');
    document.getElementById('search-button').disabled = true; // Disable button if no options selected
    return;
  } else {
    document.getElementById('search-button').disabled = false; // Enable button if options are selected
  }

  const encodedSearchInput = encodeURIComponent(searchInput); // Encode search term to handle special characters

  const searchURLs = createSearchURLs(selectedOptions, encodedSearchInput);

  try {
    for (const url of searchURLs) {
      if (url) {
        await chrome.tabs.create({ url });
      }
    }

    // Optionally clear search input after successful search
    document.getElementById('search-input').value = '';
  } catch (error) {
    console.error('Error opening tabs:', error);
    alert('Failed to open search results. Please try again.');
  }
}

// Attach event listener with error handling
document.getElementById('search-button').addEventListener('click', (event) => {
  event.preventDefault(); // Prevent default button behavior (optional)
  performSearch().catch((error) => console.error('Error during search:', error));
});

// Optionally, add event listener for Enter
